def find_subsets(lst):
    if lst==[]:
        return [[]]
    subsets = find_subsets(lst[1:])
    return subsets + [[lst[0]] + first_element for first_element in subsets]


print(find_subsets([1, 2, 3]))



