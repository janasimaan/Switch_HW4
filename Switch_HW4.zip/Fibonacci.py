def fibonacci_seq(n):
    if n<= 1:
        return n
    return fibonacci_seq(n-1) + fibonacci_seq(n-2)

n = 6
result = fibonacci_seq(n)
print(result)

